#include "../include/Server.hpp"
#include "../include/Exception.hpp"
#include "../include/Utils.hpp"
#include "../include/TextEngine.hpp"
#include <string>
#include <iostream>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

using std::cout;

Server::Server(const std::string &port, const std::string &password)
	: port(0), password(password)
{
	try
	{
		this->port = Utils::ft_stoi(port);
		if (this->port < 0 || this->port > 65535)
		{
			throw Exception("Invalid port");
		}
		initSocket();
	}
	catch (const Exception &e)
	{
		throw e;
	}
}

Server::~Server(){
	close(this->_socket);
}

void Server::run()
{
	std::cout << "Server is running on port " << this->port << std::endl;
}

void Server::initSocket()
{
	this->_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (_socket < 0)
	{
		throw Exception("Socket creation failed");
	} else {
		TextEngine::green("Socket created successfully", cout) << std::endl;
	}
	int opt = 1;
	if (setsockopt(this->_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int)) < 0)
	{
		close(this->_socket);
		throw Exception("Socket option failed");
	} else {
		TextEngine::green("Socket option set successfully", cout) << std::endl;
	}

	memset(&address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(this->port);

	if (bind(this->_socket, (struct sockaddr *)&address, sizeof(address)) < 0)
	{
		close(this->_socket);
		throw Exception("Socket bind failed");
	} else {
		TextEngine::green("Socket binded successfully", cout) << std::endl;
	}

	if (listen(this->_socket, SOMAXCONN) < 0)
	{
		close(this->_socket);
		throw Exception("Socket listen failed");
	} else {
		TextEngine::green("Socket listening successfully", cout) << std::endl;
	}
}
