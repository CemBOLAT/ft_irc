#pragma once


#include <string>
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using std::vector;
using std::string;

class Server {
	public:
		Server(const string& port, const string& password);
		virtual	~Server();
		void	run();
	private:
		Server();
		Server(const Server& other);
		Server& operator=(const Server& other);
		void	initSocket();


		int					port;
		string				password;
		int					_socket;
		struct sockaddr_in	address;


};
