#pragma once


#define USAGE "./ircserv [port] [password]"

#include <string>


namespace Utils {
	int		ft_stoi(const std::string& str);
}
